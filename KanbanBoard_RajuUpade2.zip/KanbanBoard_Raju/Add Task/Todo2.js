// Initialize Flatpickr date picker
flatpickr(".due-date", {
    dateFormat: "Y-m-d",
    minDate: new Date(),
});

// Function to create a new TO DO card
function createTodoCard() {
    const todoList = document.querySelector(".todo-list");
    const todoCard = document.createElement("div");
    todoCard.classList.add("todo-card");

    todoCard.innerHTML = `
        <input type="text" class="todo-name" placeholder="Task Title">
        <p class="Task-description"><input type="text" class="task description" placeholder="Task Description"></p>
        <div class="todo-options">
            <div class="option">
                <i class="fas fa-user"></i>
                <span>Assign Member</span>
            </div>
            <div class="option">
                <i class="far fa-calendar-alt"></i>
                <span>Due Date</span>
                <input type="date" class="due-date" placeholder="Select Date">
            </div>
            <div class="option">
                <i class="fas fa-flag"></i>
                <span>Priority</span>
                <select class="priority">
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                    <option value="low">Low</option>
                </select>
            </div>

            <div class="status">
                <i class=""></i>
                <span></span>
                <select class="">
                    <option value="null">Not start Yet</option>
                    <option value="To Do">To Do</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Done">Completed</option>
                </select>
            </div>
            <div class="option">
                <i class="fas fa-trash-alt delete-btn"></i>
                <span>Delete_task</span>
            </div>
        </div>`;

    todoList.appendChild(todoCard);

    // Event listener for Delete TO DO button
    const deleteBtn = todoCard.querySelector(".delete-btn");
    deleteBtn.addEventListener("click", function () {
        todoList.removeChild(todoCard);
    });
}

// Event listener for Add TO DO button
document.getElementById("add-todo-btn").addEventListener("click", createTodoCard);
