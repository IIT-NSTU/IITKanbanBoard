<?php

session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // ...

    $project_id = $_POST["project-Id"];
    $project_name = $_POST["project-name"];
    $supervisor = $_POST["supervisor-name"];
    $project_des = $_POST["project-description"];
    $creator_mail = $_POST["project-creator-mail"];

    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";    
    $dbname = "Kanban_Board";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    if (isset($_SESSION['rfemail'])) {
                
        $rfemail = $_SESSION['rfemail'];
    } 

    $_SESSION['project_creator_email']=$creator_mail;


    


    

    $sql = "INSERT INTO CreateProjectInfo (User_Email,Project_ID, Project_Name, Supervisor_Name, Project_Description, Project_Creator_Eail) 
    VALUES ('$rfemail','$project_id', '$project_name', '$supervisor','$project_des', '$creator_mail')";

    if ($conn->query($sql) === TRUE) {
        header("Location: home.php");
    exit;
    } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
    }

$conn->close();



}

?>