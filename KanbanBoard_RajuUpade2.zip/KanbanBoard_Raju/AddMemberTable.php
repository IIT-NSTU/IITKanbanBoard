<?php

session_start();
            
if ($_SERVER["REQUEST_METHOD"] == "POST") {


    $email = $_POST["email"];
    $project_id =$_POST['project_id'];

            // Database connection
            $servername = "localhost";
            $username = "root";
            $password = "";    
            $dbname = "Kanban_Board";

            $conn = new mysqli($servername, $username, $password, $dbname);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            
           
            if (isset($_SESSION['rfemail'])) {
                
                $rfemail = $_SESSION['rfemail'];
            } 

            if (isset($_SESSION['project_creator_email'])) {
                
                $project_creator_email = $_SESSION['project_creator_email'];
            } 

            if (isset($_SESSION['projectID'])) {
                
                $project_id = $_SESSION['projectID'];
            } 

              

            $referenceCode = generateReferenceCode();
            
            // Insert data into database
            $sql = "INSERT INTO ProjectMember (Project_ID,User_Email,Invited_Member_Email,Reference_Code) 
                    VALUES ('$project_id','$rfemail','$email','$referenceCode')";

            if ($conn->query($sql) === TRUE) {
                // Send verification email
                sendVerificationEmail($email,$rfemail, $referenceCode,$conn);
                exit;
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
            $conn->close();

}

function generateReferenceCode() {
    // Generate a random 6-character alphanumeric code
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $verificationCode = '';
    for ($i = 0; $i < 6; $i++) {
        $index = rand(0, strlen($characters) - 1);
        $verificationCode .= $characters[$index];
    }
    return $verificationCode;
}

function sendVerificationEmail($to, $rfemail, $referenceCode,$conn) {


    $subject = "Invitation mail for join Project";
    $message = "Use the reference mail and code to Join:\n";
    $message .= "Reference mail: $rfemail"  . "&Reference code=" . urlencode($referenceCode);
    $headers = "From: ij.jhumu.nstu@gmail.com"; // 

    if(mail($to, $subject, $message, $headers)){
        $_SESSION['success'] = "Invitation Successful.";

        header("Location: AddMemberForm.php");

    }else{
        $_SESSION['success'] = "Invitation failed.";
        header("Location: AddMemberForm.php");
    }

}
?>

