<?php

session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kanban_Board</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <link rel="stylesheet" href="assets/css/icons.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.2.1/dist/chart.min.js"></script>

    <style>
        /* CSS styles for the shadow boxes */
        /* CSS styles for the anchor tag wrapping the shadow box */


        .shadow-box {
            width: 270px;
            padding: 20px;
            margin: 20px;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            background-color: #f2f2f2;
            text-align: center;
            border-radius: 10px;
            transition: background-color 0.3s, transform 0.3s;
            cursor: pointer;
        }

        /* Add the hover effect */
        .shadow-box:hover {
            background-color: #b3e0ff;
            /* Change the background color on hover */
            transform: scale(1.05);
            /* Slightly increase the size on hover */
        }

        /* CSS styles for the invite and delete icons */
        .invite-icon {
            color: green;
            margin-right: 10px;
        }

        .delete-icon {
            color: red;
        }

        /* Add a pointer cursor to the icons */
        .invite-icon,
        .delete-icon {
            cursor: pointer;
        }


        .btn {
            background-color: darkgreen;
            color: #fff;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;

        }

        .btn:hover {
            background-color: maroon;
            color: yellow;
        }
    </style>



</head>

<body>
    <div class="dashboard">
        <section class="navigation">
            <img src="assets/img/logo-thumbnail.png" alt="IIT Kanban_Board" class="logo">

            <div>
                <span class="material-icons-outlined"> dashboard </span>
                <span class="material-icons-outlined"> trending_up </span>
                <a href="invite_member.php" id="peopleAlt" class="material-icons-outlined"> people_alt </a>

                <span class="material-icons-outlined"> insert_invitation </span>
                <span class="material-icons-outlined">settings_suggest</span>
            </div>

        </section><!-- Navigation End -->


        <section class="main"><!-- Main -->
            <div class="search"><!-- Search -->
                <form action="">
                    <input type="text" name="search" id="searchProject" placeholder="Search Here">
                    <span class="material-icons-outlined"> search </span>
                </form>

                <div class="notification">
                    <span class="material-icons-outlined"> notifications </span>
                    <span class="material-icons-outlined"> edit </span>
                </div>
            </div><!-- Search End -->

            <div class="title">
                <h1>My Project</h1>

                <label for="projects">Sort By</label>
                <select name="projects" id="projectFilter">
                    <option value="">...</option>
                    <option value="recent">Recent Project</option>
                    <option value="finished">Finished Project</option>
                    <option value="ongoing">Ongoing Project</option>
                    <option value="stalled">Stalled Project</option>
                </select>

            </div>

            <div class="button">
                <button class="btn" onclick="window.location.href='CreateProjectForm.html'"> Create Project</button>
            </div>
            <br>

            <div class="project_list">

                <?php
                //session_start();
                // Database connection
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "Kanban_Board";

                $conn = new mysqli($servername, $username, $password, $dbname);

                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Retrieve data from the database
                if (isset($_SESSION['rfemail'])) {

                    $rfemail = $_SESSION['rfemail'];
                }

                $sql = "SELECT Project_ID, Project_Name, Supervisor_Name, Project_Description, Project_Creator_Eail FROM CreateProjectInfo WHERE User_Email = '$rfemail'";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        // Create a shadow box for each project
                        echo '<a style="text-decoration:none; color:black;" href="TaskCreateForm.php?project_id=' . $row['Project_ID'] . '">';
                        echo '<div class="shadow-box">';
                        echo '<h2 style="color:Green">' . $row['Project_Name'] . '</h2>';
                        echo '<p><strong>Project ID:</strong> ' . $row['Project_ID'] . '</p>';
                        echo '<p><strong>Supervisor:</strong> ' . $row['Supervisor_Name'] . '</p>';
                        echo '<p><strong>Description:</strong> ' . $row['Project_Description'] . '</p>';
                        echo '<p><strong>Creator Email:</strong> ' . $row['Project_Creator_Eail'] . '</p>';


                        echo '<a href="AddMemberForm.php?project_id=' . $row['Project_ID'] . '"><i class="fas fa-user-plus invite-icon" style="color:green; margin-right:30px;"></i></a>';


                        echo '<i class="fas fa-trash-alt" style="color: red;"></i>';
                        echo '</div>';
                    }
                } else {
                    echo '<h1 style="text-align:center; color:green;margin-left:40px">Create your first Project</h1>';
                }

                $conn->close();
                ?>
            </div>
        </section><!-- Main End -->



        <section class="secondary">
            <div class="chart">
                <h2>Total Project</h2>
                <canvas id="myChart" width="400" height="400"></canvas>
            </div>
        </section>

    </div>

    <script src="assets/js/script.js"> </script>
</body>

</html>