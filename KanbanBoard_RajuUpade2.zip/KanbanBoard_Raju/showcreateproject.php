<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Homepage</title>
    <style>
        /* Add your CSS styles for the shadow boxes here */
        .shadow-box {
            width: 300px;
            padding: 20px;
            margin: 20px;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            background-color: #f2f2f2;
            text-align: center;
            border-radius: 10px;
        }

        /* Add any other CSS styles for your design here */
    </style>
</head>
<body>
    <h1>Welcome to Your Homepage</h1>

    /*<?php
    /*session_start();
    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "Kanban_Board";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Retrieve data from the database
    if (isset($_SESSION['rfemail'])) {
                
        $rfemail = $_SESSION['rfemail'];
    }

    $sql = "SELECT Project_ID, Project_Name, Supervisor_Name, Project_Description, Project_Creator_Eail FROM CreateProjectInfo WHERE User_Email = '$rfemail'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // Create a shadow box for each project
            echo '<div class="shadow-box">';
            echo '<h2>' . $row['Project_Name'] . '</h2>';
            echo '<p>Project ID: ' . $row['Project_ID'] . '</p>';
            echo '<p>Supervisor: ' . $row['Supervisor_Name'] . '</p>';
            echo '<p>Description: ' . $row['Project_Description'] . '</p>';
            echo '<p>Creator Email: ' . $row['Project_Creator_Eail'] . '</p>';
            // Add any additional design elements or icons here
            echo '</div>';
        }
    } else {
        echo '<p>No projects found.</p>';
    }

    $conn->close();
    ?>

</body>
</html> -->
