-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 06, 2023 at 09:04 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kanban_board`
--

-- --------------------------------------------------------

--
-- Table structure for table `createprojectinfo`
--

CREATE TABLE `createprojectinfo` (
  `User_Email` varchar(50) NOT NULL,
  `Project_ID` int(50) NOT NULL,
  `Project_Name` varchar(50) NOT NULL,
  `Supervisor_Name` varchar(50) NOT NULL,
  `Project_Description` varchar(50) NOT NULL,
  `Project_Creator_Eail` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `createprojectinfo`
--

INSERT INTO `createprojectinfo` (`User_Email`, `Project_ID`, `Project_Name`, `Supervisor_Name`, `Project_Description`, `Project_Creator_Eail`) VALUES
('raju.iit3@gmail.com', 1, 'Hello Project2', 'Saiful', 'SPL Project', 'smtsaiful@gmail.com'),
('raju.iit3@gmail.com', 2, 'Hello Project2', 'Dipok Chandra', 'SPL Project', 'raju.iit3@gmail.com'),
('raju.iit3@gmail.com', 3, 'Hello Project3', 'Dipok Chandra', 'SPL Project', 'raju.iit3@gmail.com'),
('raju.iit3@gmail.com', 4, 'Hello Project', 'Dipok Chandra', 'SPL Project', 'raju.iit3@gmail.com'),
('raju.iit3@gmail.com', 5, 'Hello Project', 'Dipok Chandra', 'SPL Project', 'raju.iit3@gmail.com'),
('raju.iit3@gmail.com', 6, 'Hello Project', 'Dipok Chandra', 'SPL Project', 'raju.iit3@gmail.com'),
('raju.iit3@gmail.com', 7, 'Hello Project7', 'Dipok Chandra', 'SPL Project', 'raju.iit3@gmail.com'),
('raju.iit3@gmail.com', 8, 'Hello Project7', 'Dipok Chandra', 'SPL Project', 'raju.iit3@gmail.com'),
('raju.iit3@gmail.com', 9, 'Hello Project7', 'Dipok Chandra', 'SPL Project', 'raju.iit3@gmail.com'),
('raju.iit3@gmail.com', 10, 'Hello Project7', 'Dipok Chandra', 'SPL Project', 'raju.iit3@gmail.com'),
('raju.iit3@gmail.com', 11, 'JHumu', 'Saiful', 'spl2', 'smtsaiful@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `invitemeberinfo`
--

CREATE TABLE `invitemeberinfo` (
  `User_Email` varchar(50) NOT NULL,
  `Invited_Member_Email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `invitemeberinfo`
--

INSERT INTO `invitemeberinfo` (`User_Email`, `Invited_Member_Email`) VALUES
('raju.iit3@gmail.com', 'smtsaiful@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `projectmember`
--

CREATE TABLE `projectmember` (
  `Project_ID` int(50) NOT NULL,
  `User_Email` varchar(50) NOT NULL,
  `Invited_Member_Email` varchar(50) NOT NULL,
  `Reference_Code` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `projectmember`
--

INSERT INTO `projectmember` (`Project_ID`, `User_Email`, `Invited_Member_Email`, `Reference_Code`) VALUES
(2, 'raju.iit3@gmail.com', 'smtsaiful@gmail.com', '8XfzLE'),
(7, 'raju.iit3@gmail.com', 'i.j.jhumu@gmail.com', 'fMhGAD'),
(1, 'raju.iit3@gmail.com', 'raju.iit.nstu1@gmail.com', '3MQhQH'),
(1, 'raju.iit3@gmail.com', 'smtsaiful@gmail.com', 'SX2yDG'),
(1, 'raju.iit3@gmail.com', 'i.j.jhumu@gmail.com', 'v9hc8b');

-- --------------------------------------------------------

--
-- Table structure for table `taskinfo`
--

CREATE TABLE `taskinfo` (
  `Project_ID` int(50) NOT NULL,
  `Task_Title` varchar(50) NOT NULL,
  `Assign_Member` varchar(50) NOT NULL,
  `Due_Date` datetime(5) NOT NULL,
  `Set_Priority` varchar(50) NOT NULL,
  `Status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `taskinfo`
--

INSERT INTO `taskinfo` (`Project_ID`, `Task_Title`, `Assign_Member`, `Due_Date`, `Set_Priority`, `Status`) VALUES
(1, 'ilaborate your create project', 'raju.iit.nstu1@gmail.com', '2023-09-10 00:00:00.00000', 'high', 'ToDo'),
(1, 'Complete your toDo list', 'raju.iit.nstu1@gmail.com', '2023-09-11 00:00:00.00000', 'medium', 'ToDo'),
(1, 'complete your srs', 'i.j.jhumu@gmail.com', '2023-09-14 00:00:00.00000', 'medium', 'ToDo'),
(1, 'nice work', 'smtsaiful@gmail.com', '2023-09-16 00:00:00.00000', 'low', 'ToDo'),
(1, 'raju', 'i.j.jhumu@gmail.com', '2023-09-14 00:00:00.00000', 'high', 'ToDo');

-- --------------------------------------------------------

--
-- Table structure for table `usertable`
--

CREATE TABLE `usertable` (
  `User_Email` varchar(50) NOT NULL,
  `First_Password` varchar(50) NOT NULL,
  `Correct_password` varchar(50) NOT NULL,
  `Status` varchar(50) NOT NULL,
  `VerificationCode` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `usertable`
--

INSERT INTO `usertable` (`User_Email`, `First_Password`, `Correct_password`, `Status`, `VerificationCode`) VALUES
('raju.iit3@gmail.com', '123', '202cb962ac59075b964b07152d234b70', 'Active', '9cX45N'),
('smtsaiful@gmail.com', '123', '202cb962ac59075b964b07152d234b70', 'Active', 'YF2LN1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `createprojectinfo`
--
ALTER TABLE `createprojectinfo`
  ADD PRIMARY KEY (`Project_ID`);

--
-- Indexes for table `invitemeberinfo`
--
ALTER TABLE `invitemeberinfo`
  ADD KEY `User_Email` (`User_Email`);

--
-- Indexes for table `projectmember`
--
ALTER TABLE `projectmember`
  ADD KEY `Project_ID` (`Project_ID`);

--
-- Indexes for table `taskinfo`
--
ALTER TABLE `taskinfo`
  ADD KEY `Project_ID` (`Project_ID`);

--
-- Indexes for table `usertable`
--
ALTER TABLE `usertable`
  ADD PRIMARY KEY (`User_Email`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `invitemeberinfo`
--
ALTER TABLE `invitemeberinfo`
  ADD CONSTRAINT `invitemeberinfo_ibfk_1` FOREIGN KEY (`User_Email`) REFERENCES `usertable` (`User_Email`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `projectmember`
--
ALTER TABLE `projectmember`
  ADD CONSTRAINT `projectmember_ibfk_1` FOREIGN KEY (`Project_ID`) REFERENCES `createprojectinfo` (`Project_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `taskinfo`
--
ALTER TABLE `taskinfo`
  ADD CONSTRAINT `taskinfo_ibfk_1` FOREIGN KEY (`Project_ID`) REFERENCES `createprojectinfo` (`Project_ID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
